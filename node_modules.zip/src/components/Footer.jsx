function Footer() {
    return (
      <footer className="bg-blue-800 text-white text-center p-4 mt-10">
        © 2025 Bluestock Fintech. All rights reserved.
      </footer>
    );
  }
  
  export default Footer;
  